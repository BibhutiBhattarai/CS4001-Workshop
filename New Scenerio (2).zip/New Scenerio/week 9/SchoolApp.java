public class SchoolApp {
    public static void main(String[] args) {
        Teacher t = new Teacher(1, "Ram", 20000, "Math", 5000);
        System.out.println("Teacher Annual Salary: " + t.calculateAnnualSalary());
        Staff s = new Staff(2, "Shyam", 0, 8, 500);
        System.out.println("Staff Salary: " + s.calculateSalary());
        System.out.println("College Name: " + Person.collegeName);
    }
}