public class MainClass {
    public static void main(String[] args) {
        BankAccount b1 = new BankAccount();
        BankAccount b2 = new BankAccount();
        
        b1.accNo = 101;
        b1.name = "Ram";
        b1.balance = 5000;
        
        b2.accNo = 102;
        b2.name = "Shyam";
        b2.balance = 3000;
        
        b1.deposit(1000);
        b1.withdraw(500);
        
        b2.deposit(500);
        b2.withdraw(200);
        
        b1.display();
        b2.display();
    }
}