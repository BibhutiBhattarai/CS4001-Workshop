class BankAccount {
    int accNo;
    String name;
    double balance;
    void deposit(double amount) {
        balance = balance + amount;
    }
    void withdraw(double amount) {
        balance = balance - amount;
    }
    void display() {
        System.out.println(accNo + " " + name + " " + balance);
    }
}
