import java.util.Scanner;
public class RickshawFare {
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("--------- RickshawFare Calculator -----------");
System.out.print("The length of the path in kilometers which the traveler covered must be typed: ");
double distance = sc.nextDouble();
System.out.print("The duration of time that the RickshawFare movement consumed in minutes: ");
int minutes = sc.nextInt();
System.out.print("Experts claim that the status of the individual as a local resident is needed (true/false): ");
boolean local = sc.nextBoolean();
System.out.print("The condition of the darkness is indicated by the traveler (true/false): ");
boolean night = sc.nextBoolean();
double fare = 10;
double KM = 5;
double Min = 2;
double subTotal = fare + (KM * distance) + (minutes * Min);
double nightsur = night ? (subTotal * 0.20) : 0;
double discount = (local && distance > 2) ? (subTotal * 0.10) : 0;
double grandTotal = subTotal + nightsur - discount;
System.out.println("\n----------------------");
System.out.println("The complete amount of the RickshawFare cost: " + grandTotal);
System.out.println("The individual should return for a joyful movement and may the person possess a peaceful day.");
System.out.println("------------------------");
sc.close();
}
}