public class HospitalTest {
    public static void main(String[] args) {
        Patient p1 = new Patient("Ram", 25, 5, 1000);
        Patient p2 = new Patient("Sita", 30, 10, 1000);
        
        System.out.println("Patient 1 Details:");
        System.out.println("Name: " + p1.patientName);
        System.out.println("Age: " + p1.age);
        System.out.println("Days Admitted: " + p1.daysAdmitted);
        System.out.println("Daily Charge: " + p1.dailyCharge);
        System.out.println("Total Bill: " + p1.calculateTotalBill());
        System.out.println();

        System.out.println("Patient 2 Details:");
        System.out.println("Name: " + p2.patientName);
        System.out.println("Age: " + p2.age);
        System.out.println("Days Admitted: " + p2.daysAdmitted);
        System.out.println("Daily Charge: " + p2.dailyCharge);
        System.out.println("Total Bill: " + p2.calculateTotalBill());
    }
}