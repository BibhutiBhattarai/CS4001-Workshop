import java.util.Scanner;
public class Scholorshipchecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter GPA: ");
        double gpa = sc.nextDouble();
        if (gpa >= 3.7) {
            System.out.println("Grade: A");
        } else if (gpa >= 3.0) {
            System.out.println("Grade: B");
        } else if (gpa >= 2.0) {
            System.out.println("Grade: C");
        } else if (gpa >= 1.0) {
            System.out.println("Grade: D");
        } else {
            System.out.println("Grade: F");
        }
        if (gpa >= 3.5) {
            System.out.println("Scholarship: Eligible");
        } else {
            System.out.println("Scholarship: Not Eligible");
        }
        sc.close();
    }
}